<?php 
class Student {
	private $stname = "Имя студента";
	private $stage = "Возраст студента";
	private $stgroup = "Группа студента";

	public function setName($name) {
		$this->stname = $name;
		return $this->stname;
	}

	public function getName() {
		return $this->stname;
	}

	public function setAge($age) {
		$this->stage = $age;
		return $this->stage;
	}

	public function getAge() {
		return $this->stage;
	}

	public function setGroup($group) {
		$this->stgroup = $group;
		return $this->stgroup;
	}

	public function getGroup() {
		return $this->stgroup;
	}
	
}


$Ivan = new Student;

$Ivan->setName("Иван");
$Ivan->setAge(21);
$Ivan->setGroup("U1001");

$Vacia = new Student;
$Vacia->setName("Вася");
$Vacia->setAge(20);
$Vacia->setGroup("U1002");

$sum = ($Vacia->getAge() + $Ivan->getAge());
echo $sum;
?>
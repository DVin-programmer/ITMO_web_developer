<?php 

class User {
	protected $uname = "Имя пользователя";
	protected $uage = "Возраст пользователя";

public function setName($name) {
		$this->uname = $name;
		return $this->uname;
	}

	public function getName() {
		return $this->uname;
	}

	public function setAge($age) {
		$this->stage = $age;
		return $this->uage;
	}

	public function getAge() {
		return $this->uage;
	}
}

class Worker extends User {
	private $worksalary;
	
	public function setSalary($salary) {
		$this->worksalary = $salary;
		return $this->worksalary;
	}

	public function getSalary() {
		return $this->worksalary;
	}
}

$Ivan = new Worker;

$Ivan->setName("Иван");
$Ivan->setAge(25);
$Ivan->setSalary(1000);

$Vacia = new Worker;

$Vacia->setName("Вася");
$Vacia->setAge(47);
$Vacia->setSalary(1500);

$sum = ($Ivan->getSalary() + $Vacia->getSalary());
echo $sum;
?>
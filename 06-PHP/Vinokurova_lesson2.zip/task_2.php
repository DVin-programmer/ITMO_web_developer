<?php
  $a = 3;
  if ($a == 1 || $a == 2) {
    echo 'Hello world';
  }
  else if ($a == 3) {
    echo 'Hi world';
  }
  else {
    echo 'Goodbye world';
  }
?>
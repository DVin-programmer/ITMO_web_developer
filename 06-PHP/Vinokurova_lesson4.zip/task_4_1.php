<?php
  $str1 = 'Теперь пора всем хорошим людям прийти на помощь стране';
  echo "<b>Исходная строка</b>: $str1 <br>";
  // $b - для проверки
  $str2 = 'Пора теперь стране прийти на помощь всем хорошим людям';
  
  $arr_str1 = explode(" ", $str1);
  // echo '<pre>';
  // var_dump($arr_str1);
  // echo '</pre>';


  // Преобразуем 1 слово с большой буквы
  // -------------------------------------------------------------------------
  $first_word = mb_substr(mb_strtoupper($arr_str1[1], 'utf-8'), 0, 1, 'utf-8').
  mb_substr($arr_str1[1], 1, strlen($arr_str1[1]) - 1, 'utf-8');
  // ------------------------------------------------------------

  $str3 = ucfirst($first_word).' '.mb_strtolower($arr_str1[0]).
  ' '.$arr_str1[8].' '.$arr_str1[5].' '.$arr_str1[6].' '.$arr_str1[7]
  .' '.$arr_str1[2].' '.$arr_str1[3].' '.$arr_str1[4];
  echo "<b>Полученная строка:</b> $str3";

  if (strcasecmp($str2, $str3) == 0) {
    echo '<br><br>Строки равны';
  }
?>
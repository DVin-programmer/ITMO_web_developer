<?php
  $i = 0;
  while (++$i <= 10) {
      switch ($i) {
          case 5:
            echo "Итерация 5 "; break;
          case 10:
            echo "Итерация 10"; break;
        }
    } 
?>
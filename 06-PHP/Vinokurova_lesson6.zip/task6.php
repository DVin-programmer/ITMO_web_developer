<?php
  $president = 'Путин';
  $days = '366';
  $president_answer = $_GET['president'];
  $days_answer = $_GET['days'];
  

  $res = 0;
  $correct_res = 0;
  if (strlen($president_answer) != 0) {
      $res++;
      if (strcasecmp($president_answer, $president) == 0) {
        $correct_res++;
      }
  }
  if (strlen($days_answer) != 0) {
    $res++;
    if (strcasecmp($days_answer, $days) == 0) {
      $correct_res++;
    }
  }

  echo "Вы ответили на $res вопроса, из них правильно - $correct_res";

  echo '<br><br><p><b>Ваши ответы:</b></p>';
  echo "<p>Вопрос 1. Кто является президентом России?</p>";
  echo "Вы ответили - $president_answer, правильно - $president";
  echo "<p>Вопрос 2. Сколько дней в високосном году?</p>";
  echo "Вы ответили - $days_answer, правильно - $days";

?>
<?php 
  define("c", 10);
  echo 'Константа c = '.c;
?>
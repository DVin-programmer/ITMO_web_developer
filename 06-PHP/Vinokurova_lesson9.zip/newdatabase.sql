CREATE DATABASE NewDatabase;

USE NewDatabase;

CREATE TABLE Zakaz
(
    'id' INT NOT NULL AUTO_INCREMENT,
    'Name' NOT NULL VARCHAR(25),
    'Fam' NOT NULL VARCHAR(25),
    'Email' NOT NULL VARCHAR(25),
    'Tovar' NOT NULL VARCHAR(25),
    'Col' NOT NULL INT,
    PRIMARY KEY (`id`))
);

INSERT INTO Zakaz
('id', 'Name', 'Fam', 'Email', 'Tovar', 'Col')
VALUES 
(NULL, 'Петров', 'Иван', 'petrov_ivan@gmail.com', 'Personal Computer', 1);

INSERT INTO Zakaz
('id', 'Name', 'Fam', 'Email', 'Tovar', 'Col')
VALUES
(NULL, 'Андреев', 'Василий', 'ivanov2@yandex.ru', 'MacBook', 2);

INSERT INTO Zakaz
('id', 'Name', 'Fam', 'Email', 'Tovar', 'Col')
VALUES
(NULL, 'Петров', 'Алексей', 'petrov@yandex.ru', 'Mouse', 1);



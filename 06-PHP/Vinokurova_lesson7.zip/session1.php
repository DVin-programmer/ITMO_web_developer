<?php
  session_start();
  $_SESSION['username'] = 'Sasha';
  echo "<a href='session2.php'>Перейти на страницу<a/>";
?>
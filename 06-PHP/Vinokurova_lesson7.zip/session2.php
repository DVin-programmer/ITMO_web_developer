<?php
  session_start();
  echo 'Здравствуйте, '.$_SESSION['username']."!<br>";
  echo "<a href='session3.php'>Перейти на следующую страницу<a/>";
?>
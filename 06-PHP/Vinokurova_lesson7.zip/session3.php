<?php
  session_start();
  unset($_SESSION['username']);
  session_destroy();
  echo "В массиве информация о пользователе удалена."
?>
<?php
  // Данная функция не будет выполяться поскольку происходит
  // обращение к внутренней функции bar, входящей в состав foo
  // function foo()
  // {
  //   function bar(){
  //     echo 'Hello world';
  //   }
  // } 
  // bar();

  function foo()
  {
    function bar(){
      echo 'Hello world';
    }
  }
  foo();
  bar(); 
   
?>
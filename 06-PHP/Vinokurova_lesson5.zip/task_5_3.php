 <?php
   function replace_str($str) 
   {
     $str = 'Hello world';
     return $str;
   }
   echo replace_str('Строка');
?>
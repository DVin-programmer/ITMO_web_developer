function setStyle(fontColor, fontSize) 
{
    let lst = document.getElementsByClassName("listNumbers")[0].childNodes;
    lst.forEach(element => {
        if (element.nodeType == 1)
        {
            element.style.color = fontColor;
            element.style.fontSize = fontSize;
        }
    });
    console.log(lst,fontColor,fontSize);
}

setStyle("red", "33px");
function getForm() {
    let res = {};
    res["name"] = document.getElementById("name").value;
    res["surname"] = document.getElementById("surname").value;
    res["age"] = document.getElementById("age").value;
    let pol = document.getElementsByName('sex'); 

    let item_pol = {}
    let i = 0;
    pol.forEach((item) =>
    {
        if (item.checked == true)
        {
            item_pol[i] = {};
            item_pol[i]["value"] = item.value;
            item_pol[i++]["status"] = "checked";
        }
        else 
        {
            item_pol[i] = {};
            item_pol[i]["value"] = item.value;
            item_pol[i++]["status"] = "false";
        }
    });
    res['sex'] = item_pol;
    return res;
}
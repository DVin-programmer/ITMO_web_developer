let first = document.getElementById("first");
let second = document.getElementById("second");
console.log(first);
console.log(second);